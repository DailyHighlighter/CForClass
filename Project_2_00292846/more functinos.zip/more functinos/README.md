*This file was formatted using Markdown - it is not too hard to learn and very useful. There are a few variations on markdown, this is "Git-Flavored" markdown*

*You can learn more about it here -> [https://guides.github.com/features/mastering-markdown/](https://guides.github.com/features/mastering-markdown/)*

## README
- Michael Penta 
- CIS205 L9 
- Example assignment

The progam prompts a user for a number and prints the number.

## Compile instructions 

To compile the program type the following in the terminal 

```
make
```
To run the program, type the following in the terminal
```
./main.exe
``` 

## Completion Statement
I failed to meet all requirements. I found great diffculty with with even the most basic concepts. I think the syntax was 
extremely challenging. I plan on going to your office hour to ask some questions and try to address these issues.
Please give me an F on this assignment it meets no requriements.

## Citations
No external resources were used to complete this assignment
